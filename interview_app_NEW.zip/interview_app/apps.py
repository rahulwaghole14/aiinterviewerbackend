from django.apps import AppConfig


class InterviewAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ai_platform.interview_app'
